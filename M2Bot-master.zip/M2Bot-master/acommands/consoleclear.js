//works
exports.run = (bot, message, args) =>
{
console.clear();
}
